/**
 * 
 */
/**
 * 
 */
module Clase_empleado {
}